# Saint Studio Brand Guidelines

## Logo Overview

**Saint Studio** is a geometric monogram mark built on precision and craftsmanship. The letter "S" is constructed from clean curves and angles, representing both the brand name and the refinement of visual enhancement.

- **Mark type:** Monogram (letterform mark)
- **Primary application:** Discord icon, favicon, social profiles, website header
- **Format:** Mark-only (no accompanying wordmark)

---

## The Mark

### Concept
The "S" evokes precision optical instruments and craftsmanship. Three segments (upper arc, middle line, lower arc) form a unified whole that reads at any size—from 16px favicon to large displays.

### Geometry
- Clean 135° angle in the middle section
- Circular arcs top and bottom for visual softness
- Consistent stroke width throughout
- Perfectly centered in its canvas

---

## Colour Palette

| Use | Colour | Hex | CMYK | RGB |
|---|---|---|---|---|
| **Brand Primary** | Deep Indigo | #2B3E7F | 85, 75, 0, 50 | 43, 62, 127 |
| **Black** (print/web) | Black | #000000 | 0, 0, 0, 100 | 0, 0, 0 |
| **White** (reversal) | White | #FFFFFF | 0, 0, 0, 0 | 255, 255, 255 |

### Usage
- **On light backgrounds:** Use Black or Brand Indigo
- **On dark backgrounds:** Use White
- **Stand-alone mark:** Brand Indigo is recommended for digital; Black for print
- **Monochrome contexts:** Black, White, or Brand Indigo; no gradients or effects

---

## Clear Space

Maintain a minimum clear space around the mark equal to **20% of the mark's height** on all sides. On very small applications (under 32px), this can be reduced to 10%.

```
[clear space] Mark [clear space]
```

---

## Minimum Size

- **Digital (screen):** 32px at 1x (can go to 16px for favicon)
- **Print:** 0.5 inches wide
- **Embroidery:** 1 inch wide minimum

Below 32px, use the small-size variant (`saint-studio-symbol-small.svg`) for improved legibility.

---

## Applications

### Primary: Discord Server Icon
- Use `saint-studio-symbol-square.svg`
- Colour: Brand Indigo (#2B3E7F) on white, or white on dark background
- Size: Render at 512px

### Favicon / Browser Tab
- Use `saint-studio-symbol-favicon.svg`
- Colour: Brand Indigo or Black
- Sizes: 16px, 32px, 64px (auto-generated web-icon set)

### Website / Social Media
- Use `saint-studio-symbol.svg` at 2x or 3x scale
- Colour: Brand Indigo on light backgrounds; White on dark backgrounds

### Print / Marketing
- Use `saint-studio-symbol-black.svg` for general printing
- Use `saint-studio-symbol-white.svg` for reversed (on colour)
- Maintain 1:1 aspect ratio always

---

## What NOT to Do

❌ **Don't:**
- Distort, skew, or change proportions
- Add drop shadows, glows, or 3D effects
- Outline the mark with a secondary color
- Combine with other decorative elements
- Colorize (use the approved palette only)
- Use rotated or flipped versions
- Reduce below minimum size without using the small-size cut

---

## File Guide

| File | Use |
|---|---|
| `saint-studio-symbol.svg` | Master mark; primary use |
| `saint-studio-symbol-small.svg` | Favicon / very small digital use |
| `saint-studio-symbol-black.svg` | Black-only variant (print/web) |
| `saint-studio-symbol-white.svg` | White reversal variant |
| `saint-studio-symbol-mono-2b3e7f.svg` | Brand Indigo monochrome |
| `saint-studio-symbol-square.svg` | App icon / Discord square frame |
| `saint-studio-symbol-favicon.svg` | Favicon format |
| `saint-studio-symbol-app-icon.svg` | Mobile app icon template |

---

## Questions?

For trademark clearance, test the mark against competitors and use reverse-image search to ensure uniqueness. All SVG files are vector masters; export to PNG at required resolution before use.

---

**Brand Guidelines Version 1.0**
Date: October 5, 2026
Status: Ready for deployment
